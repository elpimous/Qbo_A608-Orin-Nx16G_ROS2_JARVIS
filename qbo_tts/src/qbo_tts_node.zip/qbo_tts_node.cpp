#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>
#include <portaudio.h>
#include "sherpa-onnx/c-api/c-api.h"

#include <mutex>
#include <queue>
#include <condition_variable>
#include <vector>
#include <atomic>
#include <thread>
#include <string>

// ─── Structure de message audio ─────────────────────────────────────────────
struct AudioMsg {
  std::vector<float> samples;
  int32_t sample_rate;
};

// ─── File d'attente thread-safe ──────────────────────────────────────────────
struct AudioQueue {
  std::queue<AudioMsg>    queue;
  std::mutex              mutex;
  std::condition_variable cv;
};

static AudioQueue        g_audio_queue;
static std::atomic<bool> g_killed{false};

// ─── Thread de lecture audio (Pa_WriteStream bloquant) ──────────────────────
static void PlaybackThread() {
  Pa_Initialize();

  while (!g_killed) {
    AudioMsg msg;

    // Attente d'un nouveau message audio
    {
      std::unique_lock<std::mutex> lock(g_audio_queue.mutex);
      g_audio_queue.cv.wait(lock, [] {
        return !g_audio_queue.queue.empty() || g_killed.load();
      });
      if (g_killed) break;
      msg = std::move(g_audio_queue.queue.front());
      g_audio_queue.queue.pop();
    }

    // Ouvrir le stream PortAudio
    PaStreamParameters params{};
    params.device = Pa_GetDefaultOutputDevice();
    if (params.device == paNoDevice) {
      std::cerr << "[qbo_tts] No audio output device found!" << std::endl;
      continue;
    }
    params.channelCount              = 1;
    params.sampleFormat              = paFloat32;
    // vince : device correct (était hardcodé à 0 avant)
    params.suggestedLatency          = Pa_GetDeviceInfo(params.device)->defaultLowOutputLatency;

    PaStream* stream = nullptr;
    PaError err = Pa_OpenStream(&stream, nullptr, &params,
                                msg.sample_rate, 512, paClipOff,
                                nullptr, nullptr);   // nullptr = mode bloquant
    if (err != paNoError) {
      std::cerr << "[qbo_tts] Pa_OpenStream error: " << Pa_GetErrorText(err) << std::endl;
      continue;
    }

    Pa_StartStream(stream);

    // Écriture bloquante — simple et fiable
    err = Pa_WriteStream(stream, msg.samples.data(), msg.samples.size());
    if (err != paNoError && err != paOutputUnderflowed) {
      std::cerr << "[qbo_tts] Pa_WriteStream error: " << Pa_GetErrorText(err) << std::endl;
    }

    Pa_StopStream(stream);
    Pa_CloseStream(stream);
  }

  Pa_Terminate();
}

// ─── ROS2 Node ──────────────────────────────────────────────────────────────
class QboTTSNode : public rclcpp::Node {
public:
  QboTTSNode() : Node("qbo_tts_node") {

    this->declare_parameter<std::string>("model_path",
      "install/qbo_tts/share/qbo_tts/models/axel.onnx");
    this->declare_parameter<std::string>("tokens_path",
      "install/qbo_tts/share/qbo_tts/models/tokens.txt");
    this->declare_parameter<std::string>("espeak_data_dir",
      "install/qbo_tts/share/qbo_tts/models/espeak-ng-data");
    this->declare_parameter<int>("num_threads", 3);
    this->declare_parameter<std::string>("provider", "cuda");
    this->declare_parameter<int>("sid", 0);
    this->declare_parameter<double>("speed", 1.0);

    std::string model_path  = this->get_parameter("model_path").as_string();
    std::string tokens_path = this->get_parameter("tokens_path").as_string();
    std::string espeak_dir  = this->get_parameter("espeak_data_dir").as_string();
    int num_threads         = this->get_parameter("num_threads").as_int();
    std::string provider    = this->get_parameter("provider").as_string();

    RCLCPP_INFO(get_logger(), "Loading TTS model: %s", model_path.c_str());

    SherpaOnnxOfflineTtsConfig config{};
    config.model.vits.model    = model_path.c_str();
    config.model.vits.tokens   = tokens_path.c_str();
    config.model.vits.data_dir = espeak_dir.c_str();
    config.model.num_threads   = num_threads;
    config.model.provider      = provider.c_str();
    config.max_num_sentences   = 2;

    tts_ = SherpaOnnxCreateOfflineTts(&config);
    if (!tts_) {
      RCLCPP_ERROR(get_logger(), "Failed to load TTS model! Check paths and tokens.txt");
      rclcpp::shutdown();
      return;
    }

    sample_rate_ = SherpaOnnxOfflineTtsSampleRate(tts_);
    RCLCPP_INFO(get_logger(), "TTS ready — Sample rate: %d Hz | Provider: %s",
                sample_rate_, provider.c_str());

    // Démarrage du thread audio persistant
    playback_thread_ = std::thread(PlaybackThread);

    subscription_ = this->create_subscription<std_msgs::msg::String>(
      "/to_speak", 10,
      std::bind(&QboTTSNode::speak_callback, this, std::placeholders::_1));

    RCLCPP_INFO(get_logger(), "qbo_tts_node started");
  }

  ~QboTTSNode() {
    g_killed = true;
    g_audio_queue.cv.notify_all();   // débloquer le thread en attente
    if (playback_thread_.joinable()) playback_thread_.join();
    if (tts_) SherpaOnnxDestroyOfflineTts(tts_);
  }

private:
  void speak_callback(const std_msgs::msg::String::SharedPtr msg) {
    if (msg->data.empty()) return;

    RCLCPP_INFO(get_logger(), "Speaking: %s", msg->data.c_str());

    int    sid   = this->get_parameter("sid").as_int();
    double speed = this->get_parameter("speed").as_double();

    const SherpaOnnxGeneratedAudio* audio =
      SherpaOnnxOfflineTtsGenerate(tts_, msg->data.c_str(), sid, static_cast<float>(speed));

    if (!audio || audio->n == 0) {
      RCLCPP_WARN(get_logger(), "Empty audio generated");
      return;
    }

    // Copier les samples et les envoyer au thread audio
    AudioMsg amsg;
    amsg.samples.assign(audio->samples, audio->samples + audio->n);
    amsg.sample_rate = sample_rate_;
    SherpaOnnxDestroyOfflineTtsGeneratedAudio(audio);

    {
      std::lock_guard<std::mutex> lock(g_audio_queue.mutex);
      // vince : vider la file si un nouveau message arrive (interrompre l'ancien)
      while (!g_audio_queue.queue.empty()) g_audio_queue.queue.pop();
      g_audio_queue.queue.push(std::move(amsg));
    }
    g_audio_queue.cv.notify_one();
  }

  const SherpaOnnxOfflineTts* tts_ = nullptr;
  int sample_rate_ = 22050;

  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription_;
  std::thread playback_thread_;
};

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<QboTTSNode>());
  rclcpp::shutdown();
  return 0;
}